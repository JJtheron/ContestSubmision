/*
	Created By :Jan-Jacques Theron
	Contact: theronjanjacques@gmail.com
*/
To run this program open the index.thml file in Crome I am having issues everything else.
And enjoy. 